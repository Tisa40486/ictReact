import Header from './Header'
import "../../node_modules/@fortawesome/fontawesome-free/css/all.min.css";
import "bulma/css/bulma.min.css"
import Login from './Login'
import { useState } from 'react';
import Planning from './Planning'


function App() {
  const [token, setToken] = useState();
  return (
    <>
      <Header/>
      {!token ? (
        <Login setToken={setToken} />
      ) : (
        <Planning userInfos={token} />
      )}
      {/* <Login setToken={setToken} /> */}

    </>
  )
}

export default App
