function header() {
    return(
        <>
        <h1>
            MyPlan
        </h1>
        </>
    )
}

export default header