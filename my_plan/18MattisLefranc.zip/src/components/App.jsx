import Header from './Header'
import "../../node_modules/@fortawesome/fontawesome-free/css/all.min.css";
import Planning from './Planning'
import "bulma/css/bulma.min.css"
import Login from './Login'


function App() {
  return (
    <>
      <Header></Header>
      <Login />

      {/* <Planning></Planning> */}
    </>
  )
}

export default App
