import "bulma/css/bulma.min.css";
import { useState } from "react"

function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = () => {
        if (!email) {
            alert("Utilisateur non renseigné");
        }
        if (!password)
            alert("Mot de passe non renseigné");
    };

    return (
        <>
            <h1>Login</h1>

            <div className="field">
                <label className="label">Utilisateur</label>
                <div className="control has-icons-left">
                    <input
                        className="input"
                        type="text"
                        placeholder="Utilisateur"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <span className="icon is-left">
                        <i className="fa-solid fa-user"></i>
                    </span>
                </div>
            </div>
            <div className="field"> 
                <label className="label">Mot de passe</label>

                <div className="control has-icons-left">
                    <input
                        className="input"
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <span className="icon is-left">
                        <i className="fa-solid fa-lock"></i>
                    </span>
                </div>
            </div>
            <button className="button is-link" onClick={handleLogin}>
                Login
            </button>
        </>
    );
}

export default Login;
