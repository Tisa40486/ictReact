import Header from './Header'
import Planning from './Planning'

function App() {
  return (
    <>
      <Header></Header>
      <Planning></Planning>
    </>
  )
}

export default App
