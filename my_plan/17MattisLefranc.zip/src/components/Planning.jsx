import "bulma/css/bulma.min.css"
    
function Planning(props) {
    let planning = [
        {
            "date":"11.01.2023",
            "date2":"22-294-S4VG",
            "session":"CIE 294 - Réaliser le front-end d'une app web interactive",
            "session2":"Executive Knowledge Flavio Pacifico",
            "lieu":"Micro Informatic Systems SA Salle Pepper",
            "lieu2":"en chamard 41A", 
            "lieu3":"1442 Montagny près Yverdon" 
        },
        {
            "date":"18.01.2023",
            "date2":"22-294-S4VG",
            "session":"CIE 294 - Réaliser le front-end d'une app web interactive",
            "session2":"Executive Knowledge Flavio Pacifico",
            "lieu":"Micro Informatic Systems SA Salle Pepper",
            "lieu2":"en chamard 41A", 
            "lieu3":"1442 Montagny près Yverdon" 
        },
        {
           "date":"25.01.2023",
            "date2":"22-294-S4VG",
            "session":"CIE 294 - Réaliser le front-end d'une app web interactive",
            "session2":"Executive Knowledge Flavio Pacifico",
            "lieu":"Micro Informatic Systems SA Salle Pepper",
            "lieu2":"en chamard 41A", 
            "lieu3":"1442 Montagny près Yverdon" 
        }
    ]
    return(
        <>
            <table className="table">
                <tr>
                    <th>Date</th>
                    <th>Cours</th>
                    <th>Lieu</th>
                </tr>
                <tr>
                    <td>
                        {planning[0].date}
                        <br />
                        {planning[0].date2}

                    </td>
                    <td>
                        {planning[0].session} 
                        <br />    
                        {planning[0].session2}
                    </td>
                    <td>
                        {planning[0].lieu} 
                        <br />
                        {planning[0].lieu2}
                        <br />
                        {planning[0].lieu3}
                        
                    </td>
                </tr>
                 <tr  class="is-primary">
                    <td style={{color:"white"}}>
                        {planning[1].date}
                        <br />
                        {planning[1].date2}
                        
                    </td>
                    <td style={{color:"white"}}>
                        {planning[0].session} 
                        <br />    
                        {planning[0].session2}
                    </td>
                    <td style={{color:"white"}}>
                        {planning[0].lieu} 
                        <br />
                        {planning[0].lieu2}
                        <br />
                        {planning[0].lieu3}
                        
                    </td>
                </tr>
                <tr>                    
                    <td>
                        {planning[2].date}
                        <br />
                        {planning[2].date2}
                    </td>
                    <td>
                        {planning[0].session} 
                        <br />    
                        {planning[0].session2}
                    </td>
                    <td>
                        {planning[0].lieu} 
                        <br />
                        {planning[0].lieu2}
                        <br />
                        {planning[0].lieu3}
                    </td>                
                </tr>
            </table>
        </>
    )
}

export default Planning